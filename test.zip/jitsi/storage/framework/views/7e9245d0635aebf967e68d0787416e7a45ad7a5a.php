<h2>Hello <?php echo e($name); ?></h2>

<div>Congratulations <br/>
	 <?php echo e($body); ?>

</div><?php /**PATH C:\xampp\htdocs\laravel\jitsi\resources\views/mails.blade.php ENDPATH**/ ?>