<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AddUsers extends Model
{
    //
    protected $fillable = ['name','email','profile'];
}
