<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AddUsers;
use Mail;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Validator;

class AddUser extends Controller
{
    //
    public function index(){
    	return view('adduser');
    }

    public function adduser(Request $request){
        $details = $request->all();
        $validator = Validator::make(
            array(
                'name' => $details['name'],
                'email' => $details['email'],
                'profile' => $details['profile'],
            ),
            array(
                'name' => 'required|min:3',
                'email' => 'required|email|regex:/(.*)@gmail\.com/i|unique:add_users',
                'profile' => 'required|min:2'
            )
        );

        if ($validator -> passes()) {
            $fromEmail = config('mail.mailers.smtp.username');
            $to_name = $request->name;
            $to_email = $request->email;
            $data = array('name'=>$to_name, "body" => "You have been successfully registered with the Lyxel & Flamingo.");
              
            Mail::send('mails', $data, function($message) use ($to_name, $to_email,$fromEmail) {
            $message->to($to_email, $to_name)->subject('Laravel Test Mail');
            $message->from($fromEmail,'Lyxel & Flamingo');
            });

            $a = AddUsers::create($details);
              
            return redirect()->route('adduser');
        }else{
            return redirect()->back()->withErrors($validator)->withInput();
        }


    	
    }

    public function edituser(Request $request,$id){
    	// dd($id);
    	$id = Crypt::decrypt($id);
    	// dd($id);	
        $userDetail = AddUsers::where('id',$id)->first();
        // "dd($userDetail);"
        return view('edituser', compact('userDetail'));
    }

    public function updateUser(Request $request, $id){
        $data = $request->all();
        $validator = Validator::make(
            array(
                'name' => $data['name'],
                'profile' => $data['profile'],
            ),
            array(
                'name' => 'required|min:3',
                'profile' => 'required|min:2'
            )
        );

        if ($validator -> passes()) {
            $id = Crypt::decrypt($id);
            $details = $request->all();
            AddUsers::where('id',$id)->update($details);
            $users = AddUsers::all();
            return redirect()->route('home', compact('users'));
        }else{
            return redirect()->back()->withErrors($validator)->withInput();
        }

    }


    public function deleteUser($id){
        // $id = Crypt::decrypt($id);
        $user = AddUsers::find($id);
        $user->delete();

        $users = AddUsers::all();
        return view('home',compact('users'));
    }
}
