@extends('layouts.app')

@section('header')
    <a class="nav-link" href="{{ url('/adduser') }}">{{ __('Add User') }}</a>
@endsection
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>
               <!--  <div class="card-header">
                    <a href="{{url('/adduser')}}">Add User</a>
                </div> -->

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class= "table table-striped">
                        <thead class ="thead-dark">
                            <tr>
                                <th>S No.</th>
                                <th>Userame</th>
                                <th>Email</th>
                                <th>Profile</th>
                                <th>Action</th>
                            </tr>                                
                        </thead>
                        <tbody>        
                        <?php $i=1; ?>
                        @foreach($users as $user)
                    
                            <tr>
                                <td>{{$i}}</td>
                                <td>{{$user->name}}</td>
                                <td>{{$user->email}}</td>
                                <td>{{$user->profile}}</td>
                                <td>
                                    <a href ="{{url('edituser',Crypt::encrypt($user->id))}}">Edit</a>&nbsp;&nbsp;
                                    <a href="#" onclick = "delUser({{$user->id}})">Delete</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        
                    @endforeach 
                        </tbody>
                    </table>
                          
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<script type="text/javascript">
    function delUser(id){
        var res = confirm("Do you really want to delete the user?");
        if(res == true){

            $.ajax({
                method:"post",
                url: "deleteuser/" + id,
                data:{'id':id},
                success:function(data){
                    alert("User Deleted successfully!!!");
                    location.reload(); 
                },error:function(){
                    alert('fail')
                }
            });
        }
    }
</script>
