<?php $__env->startSection('header'); ?>
    <a class="nav-link" href="<?php echo e(url('/adduser')); ?>"><?php echo e(__('Add User')); ?></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Dashboard</div>
               <!--  <div class="card-header">
                    <a href="<?php echo e(url('/adduser')); ?>">Add User</a>
                </div> -->

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class= "table table-striped">
                        <thead class ="thead-dark">
                            <tr>
                                <th>S No.</th>
                                <th>Userame</th>
                                <th>Email</th>
                                <th>Profile</th>
                                <th>Action</th>
                            </tr>                                
                        </thead>
                        <tbody>        
                        <?php $i=1; ?>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                            <tr>
                                <td><?php echo e($i); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->profile); ?></td>
                                <td>
                                    <a href ="<?php echo e(url('edituser',Crypt::encrypt($user->id))); ?>">Edit</a>&nbsp;&nbsp;
                                    <a href="#" onclick = "delUser(<?php echo e($user->id); ?>)">Delete</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </tbody>
                    </table>
                          
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script type="text/javascript">
    function delUser(id){
        var res = confirm("Do you really want to delete the user?");
        if(res == true){

            $.ajax({
                method:"post",
                url: "deleteuser/" + id,
                data:{'id':id},
                success:function(data){
                    alert("User Deleted successfully!!!");
                    location.reload(); 
                },error:function(){
                    alert('fail')
                }
            });
        }
    }
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\jitsi\resources\views/home.blade.php ENDPATH**/ ?>