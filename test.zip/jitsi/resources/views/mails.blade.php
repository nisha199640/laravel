<h2>Hello {{$name}}</h2>

<div>Congratulations <br/>
	 {{$body}}
</div>